initial_deposit = 10000
Interest = 0.05
contribution = 100
compound_type = 'monthly'
time_period_years = 5


if compound_type == 'annual':
    n = 1
elif  compound_type == 'monthly':
    n = 12

total_amount = initial_deposit * (1 + interest / n)  ** (n * time_period_years)
total_contributions = * (((1 + interest / n) ** (n * time_period_years) -1) / (interest / n))

final_amount = total_amount + total_contributions 

print(final_amount)